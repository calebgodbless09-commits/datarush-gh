const BUNDLES_BY_NETWORK = {
  MTN: {
    "1GB": 3.50, "2GB": 6.00, "3GB": 8.50, "5GB": 14.00,
    "10GB": 27.00, "20GB": 52.00,
    "25GB": 65.00, "30GB": 78.00, "40GB": 100.00,
    "50GB": 125.00, "75GB": 175.00, "100GB": 225.00,
    "150GB": 325.00, "200GB": 425.00
  },
  Telecel: {
    "5GB": 10.00, "10GB": 20.00, "15GB": 30.00, "20GB": 40.00,
    "25GB": 50.00, "30GB": 60.00, "40GB": 80.00, "50GB": 100.00,
    "75GB": 150.00, "100GB": 200.00, "150GB": 250.00,
    "200GB": 275.00, "250GB": 300.00, "300GB": 325.00
  },
  AirtelTigo: {
    "1GB": 4.00, "2GB": 9.00, "3GB": 14.00, "4GB": 17.50,
    "5GB": 20.80, "6GB": 25.80, "7GB": 26.10, "8GB": 34.00,
    "9GB": 37.00, "10GB": 42.00, "11GB": 46.00, "12GB": 49.00,
    "13GB": 54.00, "14GB": 58.00, "15GB": 59.00,
    "20GB": 80.00, "25GB": 100.00, "30GB": 120.00, "40GB": 162.00
  }
};

const NETWORK_PREFIXES = {
  MTN: ["024", "054", "055", "059"],
  Telecel: ["020", "050"],
  AirtelTigo: ["026", "027", "056", "057"]
};

let selectedBundle = null;
let selectedNetwork = null;

const bundleGrid = document.getElementById("bundleGrid");
const summaryBundle = document.getElementById("summaryBundle");
const summaryPrice = document.getElementById("summaryPrice");
const summaryNetwork = document.getElementById("summaryNetwork");
const payBtn = document.getElementById("payBtn");
const message = document.getElementById("message");
const themeBtn = document.getElementById("themeBtn");
const whatsappBtn = document.getElementById("whatsappBtn");
const networkSelect = document.getElementById("networkSelect");
const phoneInput = document.getElementById("phone");
const WHATSAPP_NUMBER = "233595217637";

function money(value) { return `GH₵${Number(value).toFixed(2)}`; }
function currentBundles() { return selectedNetwork ? BUNDLES_BY_NETWORK[selectedNetwork] : {}; }

function normalizeGhanaPhone(value) {
  let p = String(value || "").replace(/[\s()-]/g, "");
  if (p.startsWith("+233")) p = "0" + p.slice(4);
  else if (p.startsWith("233")) p = "0" + p.slice(3);
  return p;
}

function detectNetwork(phone) {
  const p = normalizeGhanaPhone(phone);
  if (!/^0\d{9}$/.test(p)) return null;
  return Object.entries(NETWORK_PREFIXES).find(([, prefixes]) => prefixes.some(x => p.startsWith(x)))?.[0] || null;
}

function validatePhone(showMessage = true) {
  if (!phoneInput) return false;
  const p = normalizeGhanaPhone(phoneInput.value);
  const box = document.getElementById("phoneValidation");
  if (!p) {
    if (box) { box.textContent = "Enter the Ghana number that will receive the bundle."; box.className = "phone-validation neutral"; }
    return false;
  }
  if (!/^0\d{9}$/.test(p)) {
    if (box) { box.textContent = "Enter a valid Ghana phone number (e.g. 024 XXX XXXX)."; box.className = "phone-validation invalid"; }
    return false;
  }
  const detected = detectNetwork(p);
  if (selectedNetwork && detected && detected !== selectedNetwork) {
    if (box) { box.textContent = `❌ This is not a ${selectedNetwork} number. It appears to be ${detected}.`; box.className = "phone-validation invalid"; }
    return false;
  }
  if (box) { box.textContent = detected ? `✓ ${detected} number format detected.` : "✓ Ghana number format verified."; box.className = "phone-validation valid"; }
  return true;
}

function renderBundles() {
  const list = currentBundles();
  const networkReady = Boolean(selectedNetwork);
  bundleGrid.innerHTML = Object.entries(list).map(([name, price]) => `
    <button type="button" class="bundle ${name === selectedBundle ? "selected" : ""} ${networkReady ? "" : "locked"}" data-bundle="${name}" ${networkReady ? "" : "disabled"}>
      <div class="gb">${name}</div><div class="price">${money(price)}</div>
    </button>`).join("");
  document.querySelectorAll(".bundle").forEach(btn => btn.addEventListener("click", () => {
    selectedBundle = btn.dataset.bundle;
    updateSummary(); renderBundles(); activateNextStep();
  }));
}

function updateSummary() {
  const list = currentBundles();
  summaryBundle.textContent = selectedBundle || "—";
  summaryPrice.textContent = selectedBundle && list[selectedBundle] != null ? money(list[selectedBundle]) : "—";
  summaryNetwork.textContent = selectedNetwork || "Select network";
  updateWhatsAppLink();
}

function activateNextStep() {
  if (!selectedNetwork || !selectedBundle) return;
  payBtn.disabled = false; payBtn.classList.add("ready"); payBtn.innerHTML = "Continue to Checkout <span>→</span>";
  const checkout = document.querySelector(".checkout-card");
  if (checkout) { checkout.classList.add("step-ready"); setTimeout(() => checkout.scrollIntoView({behavior:"smooth",block:"center"}),80); }
}

function updateWhatsAppLink() {
  const phone = phoneInput?.value.trim() || "";
  const price = selectedBundle && selectedNetwork ? currentBundles()[selectedBundle] : null;
  const selectedLine = selectedBundle && selectedNetwork ? `\n\nMy selected offer: ${selectedBundle} on ${selectedNetwork}${price != null ? ` — ${money(price)}` : ""}${phone ? ` for ${phone}` : ""}.` : "";
  const text = `Hello DataRush GH 👋\n\nI would like more information about DataRush GH.\n\n📡 Networks: MTN, Telecel and AirtelTigo (AT).\n\n🛒 How to order: Select your network → choose your bundle → enter your phone number → continue to Paystack checkout.\n${selectedLine}\n\nPlease help me with my DataRush GH order or any questions I have. 🙏`;
  if (whatsappBtn) whatsappBtn.href = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
}

networkSelect?.addEventListener("change", () => {
  selectedNetwork = networkSelect.value || null;
  selectedBundle = null;
  payBtn.disabled = true; payBtn.classList.remove("ready"); payBtn.innerHTML = "Select a bundle <span>→</span>";
  renderBundles(); updateSummary(); validatePhone();
  if (selectedNetwork) {
    const side = document.querySelector(".bundle-side");
    side?.classList.add("step-ready");
    setTimeout(() => side?.scrollIntoView({behavior:"smooth",block:"center"}),120);
  }
});

phoneInput?.addEventListener("input", () => { validatePhone(); updateWhatsAppLink(); });

payBtn.addEventListener("click", async () => {
  if (payBtn.disabled) return;
  message.textContent = "";
  if (!selectedNetwork || !selectedBundle) { message.textContent = "Please select a network and bundle."; return; }
  if (!validatePhone()) { message.textContent = `This is not a ${selectedNetwork} number. Please check the phone number or change the selected network.`; return; }
  const phone = normalizeGhanaPhone(phoneInput.value);
  const email = document.getElementById("email").value.trim();
  const list = currentBundles();
  if (list[selectedBundle] == null) { message.textContent = "That bundle is not available on the selected network."; return; }
  payBtn.disabled = true; payBtn.innerHTML = "Connecting to Paystack...";
  try {
    const response = await fetch("/api/payments/initialize", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({bundle:selectedBundle,network:selectedNetwork,phone,email})});
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Payment failed.");
    window.location.href = data.authorization_url;
  } catch (error) { message.textContent = error.message; payBtn.disabled = false; payBtn.innerHTML = "Continue to Pay <span>→</span>"; }
});

themeBtn?.addEventListener("click", () => { document.body.classList.toggle("light-mode"); themeBtn.textContent = document.body.classList.contains("light-mode") ? "☀" : "☾"; });
const observer = new IntersectionObserver(entries => entries.forEach(entry => { if(entry.isIntersecting){entry.target.style.animationPlayState="running";observer.unobserve(entry.target);} }),{threshold:.12});
document.querySelectorAll(".section.reveal, .how-section.reveal, .support.reveal").forEach(el=>observer.observe(el));
renderBundles(); updateSummary(); validatePhone(); updateWhatsAppLink();

document.querySelectorAll('a[href="#bundles"]').forEach(link=>link.addEventListener("click",()=>{document.querySelectorAll('a[href="#bundles"]').forEach(item=>item.classList.remove("is-active"));link.classList.add("is-active");const b=document.getElementById("bundles");if(b)setTimeout(()=>b.scrollIntoView({behavior:"smooth",block:"start"}),40);}));
const root=document.documentElement;let raf=0;document.addEventListener("pointermove",e=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(()=>{root.style.setProperty("--mx",`${e.clientX/innerWidth*100}%`);root.style.setProperty("--my",`${e.clientY/innerHeight*100}%`);});});
const phoneWrap=document.querySelector(".phone-wrap");if(phoneWrap&&matchMedia("(pointer:fine)").matches){phoneWrap.addEventListener("pointermove",e=>{const r=phoneWrap.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;phoneWrap.style.transform=`translate(${x*8}px,${y*8}px)`;const ph=phoneWrap.querySelector(".phone");if(ph)ph.style.transform=`rotate(${7+x*4}deg) translateY(${y*-8}px)`;});phoneWrap.addEventListener("pointerleave",()=>{phoneWrap.style.transform="";const ph=phoneWrap.querySelector(".phone");if(ph)ph.style.transform="";});}
document.querySelectorAll("button,.primary-btn,.secondary-btn,.nav-buy").forEach(el=>el.addEventListener("click",e=>{const r=el.getBoundingClientRect(),size=Math.max(r.width,r.height),ripple=document.createElement("span");ripple.className="ripple";ripple.style.width=ripple.style.height=`${size}px`;ripple.style.left=`${e.clientX-r.left-size/2}px`;ripple.style.top=`${e.clientY-r.top-size/2}px`;el.appendChild(ripple);ripple.addEventListener("animationend",()=>ripple.remove());}));
