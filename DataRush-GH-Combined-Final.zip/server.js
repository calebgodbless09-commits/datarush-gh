require("dotenv").config();
const express = require("express");
const path = require("path");
const crypto = require("crypto");
const app = express();
const PORT = process.env.PORT || 3000;
const SITE_URL = process.env.SITE_URL || `http://localhost:${PORT}`;
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

const BUNDLES = {
  MTN:{"1GB":3.50,"2GB":6,"3GB":8.50,"5GB":14,"10GB":27,"20GB":52,"25GB":65,"30GB":78,"40GB":100,"50GB":125,"75GB":175,"100GB":225,"150GB":325,"200GB":425},
  Telecel:{"5GB":10,"10GB":20,"15GB":30,"20GB":40,"25GB":50,"30GB":60,"40GB":80,"50GB":100,"75GB":150,"100GB":200,"150GB":250,"200GB":275,"250GB":300,"300GB":325},
  AirtelTigo:{"1GB":4,"2GB":9,"3GB":14,"4GB":17.50,"5GB":20.80,"6GB":25.80,"7GB":26.10,"8GB":34,"9GB":37,"10GB":42,"11GB":46,"12GB":49,"13GB":54,"14GB":58,"15GB":59,"20GB":80,"25GB":100,"30GB":120,"40GB":162}
};
const PREFIXES={MTN:["024","054","055","059"],Telecel:["020","050"],AirtelTigo:["026","027","056","057"]};
function normalizePhone(v){let p=String(v||"").replace(/[\s()-]/g,"");if(p.startsWith("+233"))p="0"+p.slice(4);else if(p.startsWith("233"))p="0"+p.slice(3);return p;}
function detectedNetwork(p){return Object.entries(PREFIXES).find(([,xs])=>xs.some(x=>p.startsWith(x)))?.[0]||null;}
app.get("/api/bundles",(_req,res)=>res.json(BUNDLES));
app.post("/api/payments/initialize",async(req,res)=>{try{
 const {bundle,network,phone,email}=req.body; const cleanPhone=normalizePhone(phone); const catalog=BUNDLES[network];
 if(!catalog)return res.status(400).json({error:"Select a valid network."});
 if(catalog[bundle]==null)return res.status(400).json({error:"That bundle is not available on the selected network."});
 if(!/^0\d{9}$/.test(cleanPhone))return res.status(400).json({error:"Enter a valid Ghana phone number."});
 const detected=detectedNetwork(cleanPhone); if(detected&&detected!==network)return res.status(400).json({error:`This is not a ${network} number. The number appears to be ${detected}.`});
 if(email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email)))return res.status(400).json({error:"Enter a valid email address or leave it blank."});
 if(!process.env.PAYSTACK_SECRET_KEY)return res.status(500).json({error:"Paystack is not configured. Add PAYSTACK_SECRET_KEY to the Vercel environment."});
 const amountPesewas=Math.round(catalog[bundle]*100); const reference=`DRGH-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;
 const response=await fetch("https://api.paystack.co/transaction/initialize",{method:"POST",headers:{Authorization:`Bearer ${process.env.PAYSTACK_SECRET_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({email:email||`customer+${reference}@datarushgh.com`,amount:String(amountPesewas),currency:"GHS",reference,callback_url:`${SITE_URL}/payment-success.html`,channels:["card","mobile_money"],metadata:{bundle,network,phone:cleanPhone}})});
 const data=await response.json(); if(!response.ok||!data.status)return res.status(400).json({error:data.message||"Could not initialize payment."}); res.json({authorization_url:data.data.authorization_url,reference:data.data.reference});
}catch(error){console.error(error);res.status(500).json({error:"Payment initialization failed."});}});
app.get("/api/payments/verify/:reference",async(req,res)=>{try{if(!process.env.PAYSTACK_SECRET_KEY)return res.status(500).json({error:"Paystack is not configured."});const response=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(req.params.reference)}`,{headers:{Authorization:`Bearer ${process.env.PAYSTACK_SECRET_KEY}`}});const data=await response.json();if(!response.ok||!data.status)return res.status(400).json({error:data.message||"Verification failed."});const tx=data.data;res.json({status:tx.status,reference:tx.reference,amount:tx.amount,currency:tx.currency,metadata:tx.metadata,paid_at:tx.paid_at});}catch(error){console.error(error);res.status(500).json({error:"Payment verification failed."});}});
app.get("*",(_req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
module.exports=app;
if(require.main===module){app.listen(PORT,()=>console.log(`DataRush GH running at ${SITE_URL}`));}
